
from flask import Flask, request, jsonify

app = Flask(__name__)

# In-memory data store (for simplicity, no database)
books = []
members = []

# Models
def find_book(book_id):
    return next((book for book in books if book['id'] == book_id), None)

def find_member(member_id):
    return next((member for member in members if member['id'] == member_id), None)

# Routes: Books CRUD
@app.route('/books', methods=['POST'])
def add_book():
    data = request.json
    if 'id' not in data or 'title' not in data or 'author' not in data:
        return jsonify({'error': 'Missing required fields'}), 400

    if find_book(data['id']):
        return jsonify({'error': 'Book ID already exists'}), 400

    books.append(data)
    return jsonify({'message': 'Book added successfully', 'book': data}), 201

@app.route('/books', methods=['GET'])
def get_books():
    search_title = request.args.get('title')
    search_author = request.args.get('author')

    results = books
    if search_title:
        results = [book for book in results if search_title.lower() in book['title'].lower()]
    if search_author:
        results = [book for book in results if search_author.lower() in book['author'].lower()]

    return jsonify(results), 200

@app.route('/books/<int:book_id>', methods=['GET'])
def get_book(book_id):
    book = find_book(book_id)
    if not book:
        return jsonify({'error': 'Book not found'}), 404
    return jsonify(book), 200

@app.route('/books/<int:book_id>', methods=['PUT'])
def update_book(book_id):
    book = find_book(book_id)
    if not book:
        return jsonify({'error': 'Book not found'}), 404

    data = request.json
    book.update(data)
    return jsonify({'message': 'Book updated successfully', 'book': book}), 200

@app.route('/books/<int:book_id>', methods=['DELETE'])
def delete_book(book_id):
    book = find_book(book_id)
    if not book:
        return jsonify({'error': 'Book not found'}), 404

    books.remove(book)
    return jsonify({'message': 'Book deleted successfully'}), 200

# Routes: Members CRUD
@app.route('/members', methods=['POST'])
def add_member():
    data = request.json
    if 'id' not in data or 'name' not in data:
        return jsonify({'error': 'Missing required fields'}), 400

    if find_member(data['id']):
        return jsonify({'error': 'Member ID already exists'}), 400

    members.append(data)
    return jsonify({'message': 'Member added successfully', 'member': data}), 201

@app.route('/members', methods=['GET'])
def get_members():
    return jsonify(members), 200

@app.route('/members/<int:member_id>', methods=['GET'])
def get_member(member_id):
    member = find_member(member_id)
    if not member:
        return jsonify({'error': 'Member not found'}), 404
    return jsonify(member), 200

@app.route('/members/<int:member_id>', methods=['PUT'])
def update_member(member_id):
    member = find_member(member_id)
    if not member:
        return jsonify({'error': 'Member not found'}), 404

    data = request.json
    member.update(data)
    return jsonify({'message': 'Member updated successfully', 'member': member}), 200

@app.route('/members/<int:member_id>', methods=['DELETE'])
def delete_member(member_id):
    member = find_member(member_id)
    if not member:
        return jsonify({'error': 'Member not found'}), 404

    members.remove(member)
    return jsonify({'message': 'Member deleted successfully'}), 200

# Run server
if __name__ == '_main_':
    app.run(debug=True)